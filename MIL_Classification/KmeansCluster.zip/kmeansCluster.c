#include "mex.h" // ʹ��MEX�ļ����������ͷ�ļ�
#include <stdio.h>
#include <time.h>
#include<stdlib.h>


// ִ�о��幤����C����
double computeDistance( double* inst, double* centers, int i, int j, int dim )
{
    double distance = 0;
    int k;
    for( k=0; k<dim; k++)
    {
        distance += (*(inst+i*dim+k)-*(centers+j*dim+k))*(*(inst+i*dim+k)-*(centers+j*dim+k));
    }
    return distance;
}
void Cluster(double* inst, double* centers, int k, int M, int N)
{
	int i, j, temp;
    int *select;
	//����������״̬
    int complete = 0;
    int iterNum = 0;
    double **distance;
    int *clusters;
    int *clusterNum;
    double **tempCenter;
    int part;
    
    distance = (double **)malloc(sizeof(double *)*M);
    for( i = 0; i < M; i++ )
        distance[i]=(double *)malloc(sizeof(double)*k);
    
    clusters = (int *)malloc(sizeof(int)*M);
    clusterNum = (int *)malloc(sizeof(int)*k);
    
    tempCenter = (double **)malloc(sizeof(double *)*k);
    for( i = 0; i < k; i++ )
        tempCenter[i] = (double *)malloc(sizeof(double)*N);
    
    select = (int *)malloc(sizeof(int)*k);

    srand( (unsigned)time( NULL ) );  
    //��ʼ��k��center
    for( i = 0; i < k; i++)
	{
		temp = (int)(M*rand()/(RAND_MAX+1.0));
		for( j = 0; j < i; j++ )
		{
            if( *(select+j) == temp )
			{
				j = 0;
				temp = (int)(M*rand()/(RAND_MAX+1.0));
				continue;
			}
		}
		*(select+i) = temp;
	}
    
    for(i = 0; i<k; i++)
	{
	    for(j = 0; j<N; j++)
            *(centers+i*N+j) = *(inst + N*(*(select+i))+j);
	}
    
  
    //EM�㷨
    while( complete==0 )
    {
        
        //����������
        for(i = 0; i < M; i++)
            for(j = 0; j < k; j++){
                distance[i][j] = computeDistance(inst,centers,i,j,N);
            }
      
        //M
        //ͳ�Ƹ������������ʼ��
         for(i=0; i<k; i++)
            clusterNum[i] = 0;
        
        for(i = 0; i < M; i++)
        {
            double nearest = 10000;
            for(j = 0; j<k; j++)
            {
               if( distance[i][j] < nearest)
               {
                   nearest = distance[i][j];
                   clusters[i] = j;
               }
            }
            clusterNum[clusters[i]]++;
         }
    
        for(i = 0;i < k; i++)
            for( j=0; j<N; j++)
                tempCenter[i][j] = 0;
       
        for(i = 0; i< M; i++)
        {
            for(j = 0; j < N; j++)
            {
                tempCenter[clusters[i]][j] += *(inst+i*N+j);
            }
        }
        for( i = 0; i < k; i++ )
        {
            for( j = 0; j < N; j++)
            { 
                if( clusterNum[i] != 0)
                    tempCenter[i][j] /= clusterNum[i];
                else
                    tempCenter[i][j] = *(centers+N*i+j);
            }
        }
        //�ж��Ƿ���ֹ
        complete = 1;
        for(i = 0; i < k; i++)
        {
            for(j = 0; j < N; j++)
            {
                if((tempCenter[i][j]!=*(centers+i*N+j)))
                {
                    complete = 0;
                    break;
                }
            }
        }
        //����centers
        for(i = 0; i < k; i++)
            for(j = 0; j < N; j++)
                *(centers+i*N+j) = tempCenter[i][j];
        //iter

        iterNum++;
    }
    
   
    for( i = 0; i < M; i++ )
        free(*(distance+i));
    free(distance);
    
    free(clusters);
    free(clusterNum);
    
    for( i = 0; i < k; i++ )
        free(*(tempCenter+i));
    free(tempCenter);
    
    free(select);

}
// MEX�ļ��ӿں���
void mexFunction(int nlhs,mxArray *plhs[], int nrhs,const mxArray *prhs[])
{
    double *centers;
    double *instMatrix;
	double *tempCenters;
    int k, M, N;
    instMatrix = mxGetPr(prhs[0]);
	k = (int)*(mxGetPr(prhs[1]));
    centers = mxGetPr(prhs[2]);
	M = mxGetM(prhs[0]);
	N = mxGetN(prhs[0]);
    plhs[0] = mxCreateDoubleMatrix(k, N, mxREAL);
    centers = mxGetPr(plhs[0]);
   
	
    Cluster(instMatrix, centers, k, M, N);

}